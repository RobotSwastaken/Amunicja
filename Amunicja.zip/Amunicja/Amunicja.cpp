#include<iostream>
#include <fstream>
#include <vector>
#include "Amunicja.h"
#include "Bron_krotka_amunicja.h"
#include "Bron_dluga_amunicja.h"
#include "Bron_gladkolufowa_amunicja.h"
#include "Pojemnik_Amunicja.h"
using namespace std;
main()
{
	Pojemnik_Amunicja ammo;
	ammo.Pobierz_dane();
	ammo.amunicja[0].Generuj_raport(ammo.amunicja);
}
