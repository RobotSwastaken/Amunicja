#include<iostream>
#include <fstream>
#include <vector>
#include "Pojemnik_Amunicja.h"
using namespace std;
main()
{
	Pojemnik_Amunicja ammo;
	ammo.Pobierz_dane();
	ammo.Nowa_amunicja();
	ammo.Wyswietl();
	ammo.Generuj_raport();
	ammo.Zapisz_dane();
}
