#include "Amunicja.h"
#ifndef Bron_krotka_amunicja_hpp
#define Bron_krotka_amunicja_hpp
class Amunicja_do_broni_krotkiej: public Amunicja
{
	public:
		Amunicja_do_broni_krotkiej(int a,string zaplon);
		~Amunicja_do_broni_krotkiej();
};
Amunicja_do_broni_krotkiej::Amunicja_do_broni_krotkiej(int a,string zaplon)
{
	Kaliber=a;
	Rodzaj_zaplonu=zaplon;
	Ilosc_sztuk=0;
	Typ_broni="Krotka";
}
Amunicja_do_broni_krotkiej::~Amunicja_do_broni_krotkiej()
{
}
#endif
