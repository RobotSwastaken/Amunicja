#include "Amunicja.h"
#ifndef Bron_dluga_amunicja_hpp
#define Bron_dluga_amunicja_hpp
class Amunicja_do_broni_dlugiej: public Amunicja
{
	public:
		Amunicja_do_broni_dlugiej(int a,string zaplon);
		~Amunicja_do_broni_dlugiej();
};
Amunicja_do_broni_dlugiej::Amunicja_do_broni_dlugiej(int a,string zaplon)
{
	Kaliber=a;
	Rodzaj_zaplonu=zaplon;
	Ilosc_sztuk=0;
	Typ_broni="Dluga";
}
Amunicja_do_broni_dlugiej::~Amunicja_do_broni_dlugiej()
{
}
#endif
