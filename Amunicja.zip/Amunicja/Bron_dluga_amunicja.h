#include "Amunicja.h"
#ifndef Bron_dluga_amunicja_hpp
#define Bron_dluga_amunicja_hpp
class Amunicja_do_broni_dlugiej: public Amunicja
{
	public:
		Amunicja_do_broni_dlugiej(int a,string zaplon,int i);
		~Amunicja_do_broni_dlugiej();
};
Amunicja_do_broni_dlugiej::Amunicja_do_broni_dlugiej(int a,string zaplon,int i)
{
	Kaliber=a;
	Rodzaj_zaplonu=zaplon;
	Ilosc_sztuk=i;
	Typ_broni="Dluga";
}
Amunicja_do_broni_dlugiej::~Amunicja_do_broni_dlugiej()
{
}
#endif
