#include<iostream>
#include "Amunicja.h"
#include "Bron_krotka_amunicja.h"
#include "Bron_dluga_amunicja.h"
#include "Bron_gladkolufowa_amunicja.h"
#ifndef Pojemnik_Amunicja_hpp
#define Pojemnik_Amunicja_hpp
class Pojemnik_Amunicja
{
	public:
		Pojemnik_Amunicja();
		~Pojemnik_Amunicja();
		vector<Amunicja>amunicja;
		void Pobierz_dane();
		
};
Pojemnik_Amunicja::Pojemnik_Amunicja()
{
}
Pojemnik_Amunicja::~Pojemnik_Amunicja()
{
}
void Pojemnik_Amunicja::Pobierz_dane()
{
	ifstream plik("Wejscie.txt");
	string rodzaj,zaplon;
	int kaliber;
	while(!plik.eof())
	{
		plik>>rodzaj;
		plik>>kaliber;
		plik>>zaplon;
		if(rodzaj=="krotka")
		{
			amunicja.push_back( Amunicja_do_broni_krotkiej(kaliber, zaplon) );
		}
		else if(rodzaj=="dluga")
		{
			amunicja.push_back( Amunicja_do_broni_dlugiej( kaliber,zaplon ) );
		}
		else if(rodzaj=="gladkolufowa")
		{
			amunicja.push_back( Amunicja_do_broni_gladkolufowej(kaliber, zaplon) );
		}
		else
		{
			cout<<"bledna nazwa"<<endl;
		}
	}
	plik.close();
}
#endif
