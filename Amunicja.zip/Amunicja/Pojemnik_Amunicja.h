#include<iostream>
#include <vector>
#include "Bron_krotka_amunicja.h"
#include "Bron_dluga_amunicja.h"
#include "Bron_gladkolufowa_amunicja.h"
#ifndef Pojemnik_Amunicja_hpp
#define Pojemnik_Amunicja_hpp
class Pojemnik_Amunicja
{
	public:
		Pojemnik_Amunicja();
		~Pojemnik_Amunicja();
		vector<Amunicja>amunicja;
		void Pobierz_dane();//pobiera dane z pliku wejscie.txt i zapisuje je w wektorze
		void Zapisz_dane();//zapisuje dane w plliku wejscie.txt
		void Generuj_raport();// tworzy plik raport.txt, w ktorym zapisuje informacje o stanie amunicji
		void Wyswietl();//wyswietla na ekranie informacje o stanie amunicji
		void Dodaj_amunicje();//pyta urzytkownika o to ile jakiej amunicji dodac i dodaje ja
		void Usun_zuzyta_amunicje();//pyta urzytkownika o to ile jakiej amunicji usunac i usuwa ja
		void Nowa_amunicja();//tworzy nowy obiekt amunicji i zapisuje go w wektorze
		void Usun_amunicje();//usuwa obiekt amunicji z wektora

};
Pojemnik_Amunicja::Pojemnik_Amunicja()
{
}
Pojemnik_Amunicja::~Pojemnik_Amunicja()
{
}
void Pojemnik_Amunicja::Pobierz_dane()
{
	ifstream plik("Wejscie.txt");
	string rodzaj,zaplon;
	int kaliber,ilosc;
	while(!plik.eof())
	{
		plik>>rodzaj;
		plik>>kaliber;
		plik>>zaplon;
		plik>>ilosc;
		if(rodzaj=="Krotka")
		{
			amunicja.push_back( Amunicja_do_broni_krotkiej(kaliber, zaplon,ilosc) );
		}
		else if(rodzaj=="Dluga")
		{
			amunicja.push_back( Amunicja_do_broni_dlugiej( kaliber,zaplon,ilosc ) );
		}
		else if(rodzaj=="Gladkolufowa")
		{
			amunicja.push_back( Amunicja_do_broni_gladkolufowej(kaliber, zaplon,ilosc) );
		}
		else
		{
			cout<<"bledna nazwa"<<endl;
		}
	}
	plik.close();
}
void Pojemnik_Amunicja::Zapisz_dane()
{
    ofstream plik("wejscie.txt");
    for( int i = 0; i < amunicja.size(); i++ )
    {
        plik<<endl<< amunicja[i].Typ_broni <<" "<<amunicja[i].Kaliber<<" "<<amunicja[i].Rodzaj_zaplonu<<" "<<amunicja[i].Ilosc_sztuk;
    }
    plik.close();
}

void Pojemnik_Amunicja::Generuj_raport()
{
	ofstream zapisz("Raport.txt");
	for( int i = 0; i < amunicja.size(); i++ )
    {
    	zapisz<<"Bron "<<amunicja[i].Typ_broni<<" Kaliber: "<<amunicja[i].Kaliber<<" Zaplon: "<<amunicja[i].Rodzaj_zaplonu<<" Ilosc sztuk: "<<amunicja[i].Ilosc_sztuk<<endl;
    }
	zapisz.close();
}
void Pojemnik_Amunicja::Wyswietl()
{
	for( int i = 0; i < amunicja.size(); i++ )
    {
    	cout<<i+1<<". "<<"Bron "<<amunicja[i].Typ_broni<<", Kaliber: "<<amunicja[i].Kaliber<<", Zaplon: "<<amunicja[i].Rodzaj_zaplonu<<", Ilosc sztuk: "<<amunicja[i].Ilosc_sztuk<<endl;
    }
}
void Pojemnik_Amunicja::Dodaj_amunicje()
{
	Wyswietl();
	int nr,ilosc;
	do
	{
		cout<<"Podaj nr. amunicji, ktora chcesz dodac"<<endl;
		cin>>nr;
		nr--;
	}while(nr>=amunicja.size());
	cout<<"ile amunicji chcesz dodac?"<<endl;
	cin>>ilosc;
	amunicja[nr].Ilosc_sztuk=amunicja[nr].Ilosc_sztuk+ilosc;
}
void Pojemnik_Amunicja::Usun_zuzyta_amunicje()
{
	Wyswietl();
	int nr,ilosc;
	do
	{
		cout<<"Podaj nr. amunicji, ktora chcesz usunac"<<endl;
		cin>>nr;
		nr--;
	}while(nr>=amunicja.size());
	cout<<"ile amunicji chcesz usunac?"<<endl;
	cin>>ilosc;
	amunicja[nr].Ilosc_sztuk=amunicja[nr].Ilosc_sztuk-ilosc;
}
void Pojemnik_Amunicja::Nowa_amunicja()
{
	string rodzaj,zaplon;
	int kaliber;
	do
	{
		cout<<"Podaj typ broni: Krotka, Dluga lub Gladkolufowa "<<endl;
		cin>>rodzaj;
	}while((rodzaj != "Krotka")&&(rodzaj != "Dluga")&&(rodzaj != "Gladkolufowa"));
	cout<<"Podaj kaliber"<<endl;
	cin>>kaliber;
	cout<<"Podaj rodzaj zaplonu"<<endl;
	cin>>zaplon;
	if(rodzaj=="Krotka")
	{
		amunicja.push_back( Amunicja_do_broni_krotkiej(kaliber, zaplon,0) );
	}
	else if(rodzaj=="Dluga")
	{
		amunicja.push_back( Amunicja_do_broni_dlugiej( kaliber,zaplon,0 ) );
	}
	else if(rodzaj=="Gladkolufowa")
	{
		amunicja.push_back( Amunicja_do_broni_gladkolufowej(kaliber, zaplon,0) );
	}
}
void Pojemnik_Amunicja::Usun_amunicje()
{
	Wyswietl();
	int nr;
		do
	{
		cout<<"Podaj nr. amunicji, ktora chcesz usunac"<<endl;
		cin>>nr;
		nr--;
	}while(nr>=amunicja.size());
    amunicja.erase(amunicja.begin()+ nr);
}

#endif
