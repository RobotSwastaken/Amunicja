#include "Amunicja.h"
#ifndef Bron_gladkolufowa_amunicja_hpp
#define Bron_gladkolufowa_amunicja_hpp
class Amunicja_do_broni_gladkolufowej: public Amunicja
{
	public:
		Amunicja_do_broni_gladkolufowej(int a,string zaplon,int i);
		~Amunicja_do_broni_gladkolufowej();
};
Amunicja_do_broni_gladkolufowej::Amunicja_do_broni_gladkolufowej(int a,string zaplon,int i)
{
	Kaliber=a;
	Rodzaj_zaplonu=zaplon;
	Ilosc_sztuk=i;
	Typ_broni="Gladkolufowa";
}
Amunicja_do_broni_gladkolufowej::~Amunicja_do_broni_gladkolufowej()
{
}
#endif
