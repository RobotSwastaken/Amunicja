#include <vector>
#include <fstream>
#ifndef Amunicja_hpp
#define Amunicja_hpp
using namespace std;
class Amunicja
{
	public:
		Amunicja();
		~Amunicja();
		int Kaliber;
		int Ilosc_sztuk;
		string Rodzaj_zaplonu;
		string Typ_broni;
		void Dodaj_amunicje(int ilosc);
		void Usun_zuzyta_amunicje(int ilosc);
		void Generuj_raport(vector<Amunicja>amunicja);
};
Amunicja::Amunicja()
{
}
Amunicja::~Amunicja()
{
}
void Amunicja::Dodaj_amunicje(int ilosc)
{
	Ilosc_sztuk=Ilosc_sztuk+ilosc;
}
void Amunicja::Usun_zuzyta_amunicje(int ilosc)
{
	Ilosc_sztuk=Ilosc_sztuk-ilosc;
}
void Amunicja::Generuj_raport(vector<Amunicja>amunicja)
{
	ofstream zapisz("Raport.txt");
	for( int i = 0; i < amunicja.size(); i++ )
    {
    	zapisz<<"Bron "<<amunicja[i].Typ_broni<<" Kaliber: "<<amunicja[i].Kaliber<<" Zaplon: "<<amunicja[i].Rodzaj_zaplonu<<" Ilosc sztuk: "<<amunicja[i].Ilosc_sztuk<<endl;
    }
	zapisz.close();
}
#endif
