#include <vector>
#include <fstream>
#ifndef Amunicja_hpp
#define Amunicja_hpp
using namespace std;
class Amunicja
{
	public:
		Amunicja();
		~Amunicja();
		int Kaliber;
		int Ilosc_sztuk;
		string Rodzaj_zaplonu;
		string Typ_broni;
};
Amunicja::Amunicja()
{
}
Amunicja::~Amunicja()
{
}

#endif
